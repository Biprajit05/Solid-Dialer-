package com.biprajit.dialer

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Holds the live call and exposes simple actions to the UI. */
object CallManager {
    private val _call = MutableStateFlow<Call?>(null)
    val call: StateFlow<Call?> = _call

    private val _tick = MutableStateFlow(0)
    val tick: StateFlow<Int> = _tick

    private val _audio = MutableStateFlow<CallAudioState?>(null)
    val audio: StateFlow<CallAudioState?> = _audio

    var service: InCallService? = null

    private val calls = mutableListOf<Call>()
    private val handler = Handler(Looper.getMainLooper())

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = bump()
        override fun onDetailsChanged(call: Call, details: Call.Details) = bump()
    }

    private fun bump() {
        _tick.value = _tick.value + 1
    }

    fun add(call: Call) {
        calls.add(call)
        call.registerCallback(callback)
        _call.value = call
        bump()
    }

    fun remove(call: Call) {
        call.unregisterCallback(callback)
        calls.remove(call)
        _call.value = calls.lastOrNull()
        bump()
    }

    fun hasCalls() = calls.isNotEmpty()

    fun setAudio(state: CallAudioState?) {
        _audio.value = state
    }

    fun answer() {
        _call.value?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun reject() {
        _call.value?.reject(false, null)
    }

    fun hangUp() {
        _call.value?.disconnect()
    }

    fun toggleHold() {
        val c = _call.value ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    fun toggleMute() {
        val muted = _audio.value?.isMuted ?: false
        service?.setMuted(!muted)
    }

    fun toggleSpeaker() {
        val speaker = _audio.value?.route == CallAudioState.ROUTE_SPEAKER
        service?.setAudioRoute(
            if (speaker) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER
        )
    }

    fun dtmf(ch: Char) {
        val c = _call.value ?: return
        c.playDtmfTone(ch)
        handler.postDelayed({ c.stopDtmfTone() }, 150)
    }
}
