package com.biprajit.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat

class DialerInCallService : InCallService() {

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.add(call)
        if (call.state == Call.STATE_RINGING) {
            showIncoming(call)
        } else {
            openCallScreen(false)
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        if (!CallManager.hasCalls()) CallManager.service = null
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.setAudio(audioState)
    }

    private fun openCallScreen(answer: Boolean) {
        val i = Intent(this, InCallActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("answer", answer)
        }
        try {
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    private fun showIncoming(call: Call) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Incoming calls", NotificationManager.IMPORTANCE_HIGH)
        )
        val number = call.details?.handle?.schemeSpecificPart ?: ""
        val name = call.details?.contactDisplayName ?: lookupName(this, number)
            ?: number.ifBlank { "Unknown" }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, InCallActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val answer = PendingIntent.getActivity(
            this, 2,
            Intent(this, InCallActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("answer", true),
            flags
        )
        val decline = PendingIntent.getBroadcast(
            this, 3,
            Intent(this, CallActionReceiver::class.java).setAction("decline"),
            flags
        )

        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(name)
            .setContentText("Incoming call")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .addAction(0, "Decline", decline)
            .addAction(0, "Answer", answer)
            .build()
        nm.notify(NOTIF_ID, n)
    }

    companion object {
        const val CHANNEL = "incoming_calls"
        const val NOTIF_ID = 42
    }
}

class CallActionReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "decline") CallManager.reject()
    }
}
