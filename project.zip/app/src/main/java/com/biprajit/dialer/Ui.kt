package com.biprajit.dialer

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Pal {
    val Bg = Color(0xFF0B0F19)
    val Surface = Color(0xFF151B2B)
    val Surface2 = Color(0xFF1F2842)
    val Accent = Color(0xFF4C8DFF)
    val Green = Color(0xFF2ECC71)
    val Red = Color(0xFFFF4D4F)
    val Text = Color(0xFFEAF0FF)
    val Muted = Color(0xFF8A94AD)
}

private val avatarColors = listOf(
    Color(0xFF4C8DFF), Color(0xFF8E6CFF), Color(0xFF1FB5A8),
    Color(0xFFFF8A4C), Color(0xFFE05A9C), Color(0xFF5BA84A)
)

@Composable
fun Avatar(name: String, size: Dp = 46.dp) {
    val initial = name.trim().firstOrNull { it.isLetter() }?.uppercaseChar()?.toString() ?: "#"
    val color = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.25f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            initial,
            color = color,
            fontSize = (size.value * 0.42f).sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun KeyButton(
    main: String,
    sub: String,
    onTap: () -> Unit,
    onLong: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .size(78.dp)
            .clip(CircleShape)
            .background(Pal.Surface)
            .pointerInput(onLong != null) {
                detectTapGestures(
                    onTap = { onTap() },
                    onLongPress = onLong?.let { f -> { _: Offset -> f() } }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(main, color = Pal.Text, fontSize = 30.sp, fontWeight = FontWeight.Medium)
            if (sub.isNotEmpty()) {
                Text(sub, color = Pal.Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            }
        }
    }
}

private val keyRows = listOf(
    listOf("1" to "", "2" to "ABC", "3" to "DEF"),
    listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
    listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
    listOf("*" to "", "0" to "+", "#" to "")
)

@Composable
fun Keypad(onKey: (String) -> Unit, onLongZero: (() -> Unit)? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        keyRows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
                row.forEach { (k, sub) ->
                    KeyButton(
                        main = k,
                        sub = sub,
                        onTap = { onKey(k) },
                        onLong = if (k == "0") onLongZero else null
                    )
                }
            }
        }
    }
}
