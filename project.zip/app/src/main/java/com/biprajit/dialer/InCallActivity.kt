package com.biprajit.dialer

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        // The screen simply stays on during calls. This app never asks for the
        // proximity-sensor wake lock, so nothing turns the display off when the
        // phone is held to your ear.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        handle(intent)
        setContent { InCallScreen(onFinish = { finishAndRemoveTask() }) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("answer", false) == true) {
            CallManager.answer()
            i.removeExtra("answer")
        }
    }
}

@Composable
fun CtrlButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(if (active) Pal.Text else Pal.Surface2)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (active) Pal.Bg else Pal.Text, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Pal.Muted, fontSize = 12.sp)
    }
}

@Composable
fun RoundAction(icon: ImageVector, color: Color, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(color)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Pal.Muted, fontSize = 12.sp)
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val call by CallManager.call.collectAsState()
    val tick by CallManager.tick.collectAsState()
    val audio by CallManager.audio.collectAsState()
    var showPad by remember { mutableStateOf(false) }
    var dtmf by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }

    val c = call
    val bg = Brush.verticalGradient(listOf(Color(0xFF16213E), Pal.Bg))

    if (c == null) {
        LaunchedEffect(Unit) {
            delay(400)
            onFinish()
        }
        Box(Modifier.fillMaxSize().background(bg))
        return
    }

    val state = remember(tick, c) { c.state }
    val number = remember(tick, c) { c.details?.handle?.schemeSpecificPart ?: "" }
    val name = remember(c, number) {
        c.details?.contactDisplayName ?: lookupName(ctx, number) ?: number.ifBlank { "Unknown" }
    }
    val connectTime = remember(tick, c) { c.details?.connectTimeMillis ?: 0L }

    val status = when (state) {
        Call.STATE_RINGING -> "Incoming call"
        Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
        Call.STATE_HOLDING -> "On hold"
        Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call ended"
        Call.STATE_ACTIVE -> {
            val secs = if (connectTime > 0) ((now - connectTime) / 1000).coerceAtLeast(0) else 0
            "%02d:%02d".format(secs / 60, secs % 60)
        }
        else -> ""
    }

    val muted = audio?.isMuted ?: false
    val speaker = audio?.route == CallAudioState.ROUTE_SPEAKER
    val ringing = state == Call.STATE_RINGING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(56.dp))
        Avatar(name, size = 112.dp)
        Spacer(Modifier.height(20.dp))
        Text(
            name,
            color = Pal.Text,
            fontSize = 30.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        if (name != number && number.isNotBlank()) {
            Text(number, color = Pal.Muted, fontSize = 15.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(status, color = Pal.Accent, fontSize = 18.sp)

        if (showPad && !ringing) {
            Spacer(Modifier.height(12.dp))
            Text(dtmf, color = Pal.Text, fontSize = 24.sp, modifier = Modifier.height(32.dp))
            Keypad(onKey = { k ->
                dtmf += k
                CallManager.dtmf(k[0])
            })
        }

        Spacer(Modifier.weight(1f))

        if (ringing) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 56.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                RoundAction(Icons.Filled.CallEnd, Pal.Red, "Decline") { CallManager.reject() }
                RoundAction(Icons.Filled.Call, Pal.Green, "Answer") { CallManager.answer() }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CtrlButton(
                    if (muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                    "Mute", muted
                ) { CallManager.toggleMute() }
                CtrlButton(Icons.Filled.Dialpad, "Keypad", showPad) { showPad = !showPad }
                CtrlButton(Icons.Filled.VolumeUp, "Speaker", speaker) { CallManager.toggleSpeaker() }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 40.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CtrlButton(
                    if (state == Call.STATE_HOLDING) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                    if (state == Call.STATE_HOLDING) "Resume" else "Hold",
                    state == Call.STATE_HOLDING
                ) { CallManager.toggleHold() }
                RoundAction(Icons.Filled.CallEnd, Pal.Red, "End") { CallManager.hangUp() }
                Spacer(Modifier.size(68.dp))
            }
        }
    }
}
