package com.biprajit.dialer

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun placeCall(ctx: Context, number: String) {
    if (number.isBlank()) return
    try {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.placeCall(Uri.fromParts("tel", number, null), Bundle())
    } catch (_: SecurityException) {
    }
}

@Composable
fun App(
    refresh: Int,
    initialNumber: String,
    onRequestPerms: () -> Unit,
    onRequestDefault: () -> Unit
) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var number by remember(initialNumber) { mutableStateOf(initialNumber) }

    val hasLog = remember(refresh) { hasPermission(ctx, Manifest.permission.READ_CALL_LOG) }
    val hasContacts = remember(refresh) { hasPermission(ctx, Manifest.permission.READ_CONTACTS) }
    val isDefault = remember(refresh) {
        ctx.getSystemService(TelecomManager::class.java).defaultDialerPackage == ctx.packageName
    }
    val recents = remember(refresh, hasLog) { loadRecents(ctx) }
    val contacts = remember(refresh, hasContacts) { loadContacts(ctx) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Pal.Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        if (!isDefault) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Pal.Surface2)
                    .clickable { onRequestDefault() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Make this your phone app", color = Pal.Text, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Needed so calls show here and the screen stays on.",
                        color = Pal.Muted, fontSize = 13.sp
                    )
                }
                Text("SET", color = Pal.Accent, fontWeight = FontWeight.Bold)
            }
        }

        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DialTab(number, { number = it }, contacts)
                1 -> RecentsTab(recents, hasLog, onRequestPerms)
                else -> ContactsTab(contacts, hasContacts, onRequestPerms)
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Pal.Surface)
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavItem(Icons.Filled.Dialpad, "Keypad", tab == 0) { tab = 0 }
            NavItem(Icons.Filled.History, "Recents", tab == 1) { tab = 1 }
            NavItem(Icons.Filled.Contacts, "Contacts", tab == 2) { tab = 2 }
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val color = if (selected) Pal.Accent else Pal.Muted
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 22.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = color)
        Text(label, color = color, fontSize = 12.sp)
    }
}

@Composable
private fun DialTab(number: String, onChange: (String) -> Unit, contacts: List<ContactItem>) {
    val ctx = LocalContext.current
    val match = remember(number, contacts) {
        val d = digitsOnly(number)
        if (d.length < 3) null
        else contacts.firstOrNull { digitsOnly(it.number).endsWith(d) || digitsOnly(it.number).contains(d) }
    }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        Text(
            number.ifEmpty { " " },
            color = Pal.Text,
            fontSize = if (number.length > 12) 28.sp else 38.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Text(
            match?.name ?: " ",
            color = Pal.Accent,
            fontSize = 15.sp,
            modifier = Modifier.height(24.dp)
        )
        Spacer(Modifier.height(20.dp))
        Keypad(
            onKey = { onChange(number + it) },
            onLongZero = { onChange("$number+") }
        )
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.size(64.dp))
            Spacer(Modifier.width(26.dp))
            Box(
                Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(Pal.Green)
                    .clickable { placeCall(ctx, number) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Call, "Call", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.width(26.dp))
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .pointerInput(number) {
                        detectTapGestures(
                            onTap = { if (number.isNotEmpty()) onChange(number.dropLast(1)) },
                            onLongPress = { onChange("") }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) {
                    Icon(Icons.Filled.Backspace, "Delete", tint = Pal.Muted)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Header(title: String) {
    Text(
        title,
        color = Pal.Text,
        fontSize = 30.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 10.dp)
    )
}

@Composable
private fun PermissionCard(text: String, onRequestPerms: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Pal.Surface)
            .clickable { onRequestPerms() }
            .padding(20.dp)
    ) {
        Text(text, color = Pal.Text)
        Spacer(Modifier.height(8.dp))
        Text("Tap to allow", color = Pal.Accent, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RecentsTab(recents: List<RecentCall>, allowed: Boolean, onRequestPerms: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header("Recents")
        if (!allowed) {
            PermissionCard("Allow call history to see your recent calls.", onRequestPerms)
        } else if (recents.isEmpty()) {
            Text("No calls yet", color = Pal.Muted, modifier = Modifier.padding(20.dp))
        } else {
            LazyColumn {
                items(recents) { r ->
                    val title = r.name.ifBlank { r.number.ifBlank { "Unknown" } }
                    val missed = r.type == CallLog.Calls.MISSED_TYPE ||
                        r.type == CallLog.Calls.REJECTED_TYPE
                    val icon = when (r.type) {
                        CallLog.Calls.OUTGOING_TYPE -> Icons.Filled.CallMade
                        CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.Filled.CallMissed
                        else -> Icons.Filled.CallReceived
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { placeCall(ctx, r.number) }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(title)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                title,
                                color = if (missed) Pal.Red else Pal.Text,
                                fontSize = 17.sp,
                                maxLines = 1
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    icon, null,
                                    tint = if (missed) Pal.Red else Pal.Muted,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    DateUtils.getRelativeTimeSpanString(
                                        r.date, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
                                    ).toString(),
                                    color = Pal.Muted, fontSize = 13.sp
                                )
                            }
                        }
                        Icon(Icons.Filled.Call, "Call", tint = Pal.Accent)
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactsTab(contacts: List<ContactItem>, allowed: Boolean, onRequestPerms: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = remember(query, contacts) {
        if (query.isBlank()) contacts
        else contacts.filter {
            it.name.contains(query, ignoreCase = true) || digitsOnly(it.number).contains(digitsOnly(query).ifEmpty { "\u0000" })
        }
    }
    Column(Modifier.fillMaxSize()) {
        Header("Contacts")
        if (!allowed) {
            PermissionCard("Allow contacts access to see your people here.", onRequestPerms)
        } else {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Pal.Surface)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, null, tint = Pal.Muted)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search contacts", color = Pal.Muted, fontSize = 16.sp)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Pal.Text, fontSize = 16.sp),
                        cursorBrush = SolidColor(Pal.Accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            LazyColumn {
                items(shown) { c ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { placeCall(ctx, c.number) }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.name)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = Pal.Text, fontSize = 17.sp, maxLines = 1)
                            Text(c.number, color = Pal.Muted, fontSize = 13.sp)
                        }
                        Icon(Icons.Filled.Call, "Call", tint = Pal.Accent)
                    }
                }
            }
        }
    }
}
