package com.biprajit.dialer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ContactItem(val name: String, val number: String)

data class RecentCall(
    val name: String,
    val number: String,
    val type: Int,
    val date: Long
)

fun hasPermission(ctx: Context, perm: String): Boolean =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

fun digitsOnly(s: String): String = s.filter { it.isDigit() }

fun loadContacts(ctx: Context): List<ContactItem> {
    if (!hasPermission(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
    val out = mutableListOf<ContactItem>()
    val seen = HashSet<String>()
    try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                if (seen.add(name + "|" + digitsOnly(number))) {
                    out.add(ContactItem(name, number))
                }
            }
        }
    } catch (_: Exception) {
    }
    return out
}

fun loadRecents(ctx: Context): List<RecentCall> {
    if (!hasPermission(ctx, Manifest.permission.READ_CALL_LOG)) return emptyList()
    val out = mutableListOf<RecentCall>()
    try {
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE
            ),
            null, null,
            CallLog.Calls.DATE + " DESC"
        )?.use { c ->
            while (c.moveToNext() && out.size < 100) {
                val number = c.getString(1) ?: ""
                val name = c.getString(0) ?: ""
                out.add(RecentCall(name, number, c.getInt(2), c.getLong(3)))
            }
        }
    } catch (_: Exception) {
    }
    return out
}

fun lookupName(ctx: Context, number: String): String? {
    if (number.isBlank() || !hasPermission(ctx, Manifest.permission.READ_CONTACTS)) return null
    return try {
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
        )
        ctx.contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (_: Exception) {
        null
    }
}
